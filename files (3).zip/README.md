# Water Pipeline Leakage Monitoring System

A local, framework-free web dashboard that replaces MATLAB for signal
visualization and processing in the *Piezoelectric Vibration-Based Water
Pipeline Leakage Detection and Signal Analysis System* capstone project.

It runs entirely in the browser: no backend, no database, no Python or
MATLAB required. It works immediately in **simulation mode**, and is
ready to accept real ESP32 data over USB the moment your hardware is
built.

---

## 1. Create the project folder

Create a folder anywhere on your computer, e.g. `water-leakage-monitor`,
and place these files directly inside it (not in a subfolder):

```
water-leakage-monitor/
├── index.html
├── style.css
├── app.js
├── signal-processing.js
├── serial.js
├── simulation.js
└── README.md
```

## 2. Where each file goes / what it does

| File | Role |
|---|---|
| `index.html` | Page structure: status card, three charts, stat cards, baseline panel, comparison table, source controls, recording controls. |
| `style.css` | All styling (dark engineering-console theme). |
| `signal-processing.js` | The actual DSP: band-pass filter, FFT, RMS, peak, dominant frequency, band power, baseline comparison / detection logic. Used identically for both data sources. |
| `simulation.js` | Generates realistic Normal / Leak vibration-like sample streams. |
| `serial.js` | Web Serial API connection to a real ESP32 over USB. |
| `app.js` | Wires everything together: sample buffer, chart updates, UI events, recording, CSV export. |

All files must stay in the **same folder** — the `<script>` tags in
`index.html` reference them by relative path.

## 3. How to run it in VS Code

1. Open the `water-leakage-monitor` folder in VS Code (`File → Open Folder`).
2. Install the **Live Server** extension if you don't have it (Extensions panel → search "Live Server" by Ritwick Dey).
3. Right-click `index.html` → **Open with Live Server**.
4. Your browser opens the dashboard, already running in simulation mode.

You can also just double-click `index.html` to open it directly in a
browser, but **ESP32 connection requires Web Serial, which needs
`http://localhost` or `https://`** — plain `file://` opening will disable
the Connect button. Live Server (or `python -m http.server`) solves this.

## 4. How to start simulation mode

Simulation starts automatically when the page loads. To demonstrate:

1. In the **Simulation** panel, leave mode on **Normal flow** for ~5–10 seconds.
2. Click **Set normal baseline** — this locks in the current RMS, peak, dominant frequency, and band power as the reference.
3. Switch mode to **Leak condition**, optionally raise **Leak intensity**.
4. Watch the **System status** card flip from `NORMAL PIPELINE` to `LEAK DETECTED`, and the comparison table fill in the percentage changes that triggered it.

Adjust **Noise level**, **Vibration amplitude**, and **Simulation
frequency** sliders to show the examiner that the waveforms and FFT
respond live to input changes — this is the single best thing to
demonstrate in your viva.

## 5. How to connect the ESP32 later

1. Flash your ESP32 with firmware that reads the ADC and prints one
   sample per line over Serial (see format in section 8).
2. Plug the ESP32 into your laptop via USB.
3. On the dashboard, click **Connect ESP32**.
4. Your browser will show a device picker — select the ESP32's serial
   port and click Connect.
5. The badge in the top bar switches from `Simulation mode` to
   `ESP32 connected`, and all charts now show live hardware data through
   the exact same processing pipeline used in simulation.
6. Click **Disconnect** to release the port (needed before you can
   re-flash the board from the Arduino IDE).

**Browser requirement:** Web Serial is supported in desktop Chrome and
Edge only (not Firefox or Safari). If unsupported, the Connect button is
disabled and a message explains why.

## 6. Where to change the ESP32 sampling rate

Two places:

- **UI:** the "Sampling freq (Hz)" field above the Filtered Signal chart — change this to match whatever rate your ESP32 firmware actually samples at. This value feeds directly into the FFT frequency-axis calculation and the digital filter's cutoff math.
- **Code (optional default):** in `index.html`, the `samplingFreq` input's `value="500"` attribute sets the default shown on page load.

The sampling rate is **not hard-coded into the processing logic** —
`signal-processing.js` takes `fs` as a parameter everywhere it's needed,
specifically so you can finalize it experimentally once the real piezo
sensor and analog front-end are connected.

## 7. Where to modify detection thresholds after collecting real data

Open `signal-processing.js` and find:

```js
const DETECTION_THRESHOLDS = {
  rmsChangePct: 40,       // % increase in RMS vs baseline to flag
  bandPowerChangePct: 60, // % increase in band power vs baseline to flag
  freqShiftHz: 8,         // Hz shift in dominant frequency to flag
};
```

These three numbers are the **entire** detection rule. Once you've
recorded real Normal and Leak sessions with the actual hardware (use
the CSV export to capture them), replace these placeholder numbers with
values derived from your real measurements. The dashboard already
labels this logic as prototype/demo in the UI so you are not
overclaiming validated accuracy before that's done.

## 8. Expected ESP32 serial data format

One sample per line (simplest, recommended):
```
512
515
519
520
```

Or comma-separated groups per line (also supported):
```
512,515,519,520
```

Minimal ESP32 Arduino sketch to produce this:
```cpp
void setup() {
  Serial.begin(115200);
}
void loop() {
  int value = analogRead(34); // your ADC pin
  Serial.println(value);
  delayMicroseconds(2000);    // ~500 Hz sample rate
}
```

If your real format differs (e.g. you add a timestamp column), edit the
**PARSE LOGIC** block inside `serial.js` — it's a single, clearly marked
section (`handleChunk` / `pushValue`).

## 9. How the pipeline works (for your viva)

```
Data source (Simulation OR ESP32 Serial)
        │  addSample(value)   <-- identical call from both sources
        ▼
Rolling sample buffer (app.js)
        │
        ├─► Raw signal chart (time domain)
        │
        ▼
Digital band-pass filter (signal-processing.js: bandpassFilter)
        │
        ▼
Filtered signal chart (time domain)
        │
        ▼
Windowed FFT with Hann window (signal-processing.js: magnitudeSpectrum)
        │
        ▼
Frequency spectrum chart + dominant frequency/magnitude
        │
        ▼
Feature extraction: RMS, peak, band power, signal energy
        │
        ▼
Baseline comparison (percentage change vs. stored Normal baseline)
        │
        ▼
NORMAL / LEAK DETECTED decision + comparison table
```

Both data sources call the **same** `addSample()` function in `app.js`,
which is why there's only one processing path in the whole codebase —
useful to point out if asked "how do simulation and real hardware share
code?"

**Digital filter explanation:** implemented as a cascaded 1st-order
high-pass (removes slow drift below the low cutoff) followed by a
1st-order low-pass (removes fast noise above the high cutoff) — the
direct digital equivalent of an analog RC filter, chosen so it's easy
to derive and explain rather than a black-box library call.

**FFT explanation:** a standard iterative radix-2 Cooley-Tukey FFT,
applied to the most recent power-of-two window (up to 256 samples)
after a Hann window is applied to reduce spectral leakage.

## 10. Troubleshooting

| Problem | Fix |
|---|---|
| Charts stay empty | Make sure simulation is running (it auto-starts) or ESP32 is connected. Check the browser console (F12) for errors. |
| "Connect ESP32" button is greyed out | You're opening the file directly (`file://`) or using an unsupported browser. Use Live Server + Chrome/Edge. |
| Connect ESP32 does nothing when clicked | The device picker dialog may have opened behind the window, or no serial devices are available — check the ESP32 is plugged in and not already open in the Arduino IDE Serial Monitor (only one program can hold the port at a time). |
| Status stuck on "AWAITING BASELINE" | Click **Set normal baseline** once you have a few seconds of Normal-flow data. |
| FFT looks empty/flat | You need at least ~16 samples buffered before the FFT window is usable; wait a second after starting. |
| CSV export button disabled | You must click **Stop recording** before **Export CSV** becomes available. |
| Numbers look wrong / huge | Check the ESP32 baud rate in your firmware matches `115200` in `serial.js`, and that your serial format matches section 8. |

---

**Reminder for your report/viva:** everything labeled *Simulation / demo
data* is synthetic and only used to prove the signal-processing pipeline
and UI work end-to-end before hardware is available. Detection
thresholds are prototype values (`signal-processing.js`) and must be
replaced with experimentally measured values once you've collected real
Normal vs. Leak data from the actual piezo sensor and pipeline.
