/*
 * serial.js
 * -----------------------------------------------------------------------
 * Real ESP32 data source over the browser Web Serial API. Feeds the
 * SAME onSample(value) callback shape as simulation.js.
 *
 * Expected ESP32 serial format (one sample per line, or comma-separated
 * groups of samples per line):
 *    512
 *    515
 *    519
 * or
 *    512,515,519,520
 *
 * Change PARSE LOGIC below if your ESP32 sends a different format
 * (e.g. a "value,timestamp" pair) -- see README.md.
 * -----------------------------------------------------------------------
 */

const SerialSource = (() => {
  let port = null;
  let reader = null;
  let keepReading = false;
  let onSampleCallback = null;
  let onStatusChange = null;
  let lineBuffer = '';

  function isSupported() {
    return 'serial' in navigator;
  }

  async function connect(onSample, statusCallback) {
    onSampleCallback = onSample;
    onStatusChange = statusCallback;

    if (!isSupported()) {
      onStatusChange && onStatusChange('unsupported', 'Web Serial API is not available in this browser. Use Chrome or Edge over HTTPS or localhost.');
      return false;
    }

    try {
      port = await navigator.serial.requestPort();
      await port.open({ baudRate: 115200 });
      keepReading = true;
      onStatusChange && onStatusChange('connected', 'ESP32 connected.');
      readLoop();
      return true;
    } catch (err) {
      onStatusChange && onStatusChange('error', `Could not open serial port: ${err.message}`);
      return false;
    }
  }

  async function readLoop() {
    const textDecoder = new TextDecoderStream();
    const readableClosed = port.readable.pipeTo(textDecoder.writable);
    reader = textDecoder.readable.getReader();

    try {
      while (keepReading) {
        const { value, done } = await reader.read();
        if (done) break;
        if (value) handleChunk(value);
      }
    } catch (err) {
      onStatusChange && onStatusChange('error', `Serial read error: ${err.message}`);
    } finally {
      reader.releaseLock();
    }
  }

  function handleChunk(chunk) {
    lineBuffer += chunk;
    const lines = lineBuffer.split('\n');
    lineBuffer = lines.pop(); // keep the last, possibly incomplete, line

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) continue;

      // --- PARSE LOGIC: change here if the ESP32 format changes ---
      if (line.includes(',')) {
        line.split(',').forEach(part => pushValue(part));
      } else {
        pushValue(line);
      }
    }
  }

  function pushValue(text) {
    const num = parseFloat(text);
    if (!Number.isNaN(num) && onSampleCallback) {
      onSampleCallback(num);
    }
  }

  async function disconnect() {
    keepReading = false;
    try {
      if (reader) await reader.cancel();
      if (port) await port.close();
    } catch (err) {
      // ignore close errors
    }
    port = null;
    reader = null;
    onStatusChange && onStatusChange('disconnected', 'ESP32 disconnected. Switched to simulation mode.');
  }

  function isConnected() {
    return port !== null && keepReading;
  }

  return { isSupported, connect, disconnect, isConnected };
})();
