/*
 * signal-processing.js
 * -----------------------------------------------------------------------
 * Pure, framework-free signal processing used by BOTH the simulation
 * pipeline and the real ESP32 serial pipeline (app.js calls this module
 * the same way regardless of data source, per the "single pipeline"
 * requirement).
 *
 * Everything here is intentionally simple and readable so it can be
 * explained in a viva and modified once real experimental data is
 * collected. Nothing here is a "black box" library.
 * -----------------------------------------------------------------------
 */

const SignalProcessing = (() => {

  /**
   * Simple cascaded digital band-pass filter.
   * Implemented as a 1st-order high-pass (removes slow drift / DC below
   * lowCutoffHz) followed by a 1st-order low-pass (removes fast noise
   * above highCutoffHz). This is the standard RC-equivalent digital
   * filter, easy to derive and explain, and deliberately NOT a fixed/
   * hard-coded "scientifically validated" filter -- cutoffs are passed
   * in from the UI and are meant to be tuned experimentally once the
   * real piezo sensor is connected.
   *
   * @param {number[]} samples
   * @param {number} lowCutoffHz
   * @param {number} highCutoffHz
   * @param {number} fs sampling frequency in Hz
   * @returns {number[]} filtered samples, same length as input
   */
  function bandpassFilter(samples, lowCutoffHz, highCutoffHz, fs) {
    if (samples.length === 0) return [];
    const dt = 1 / fs;

    // --- high-pass stage (blocks DC / slow drift) ---
    const rcHigh = 1 / (2 * Math.PI * Math.max(lowCutoffHz, 0.01));
    const alphaHP = rcHigh / (rcHigh + dt);
    const hp = new Array(samples.length);
    hp[0] = 0;
    for (let i = 1; i < samples.length; i++) {
      hp[i] = alphaHP * (hp[i - 1] + samples[i] - samples[i - 1]);
    }

    // --- low-pass stage (blocks fast noise above highCutoff) ---
    const rcLow = 1 / (2 * Math.PI * Math.max(highCutoffHz, 0.01));
    const alphaLP = dt / (rcLow + dt);
    const out = new Array(samples.length);
    out[0] = hp[0];
    for (let i = 1; i < samples.length; i++) {
      out[i] = out[i - 1] + alphaLP * (hp[i] - out[i - 1]);
    }
    return out;
  }

  /**
   * Iterative radix-2 Cooley-Tukey FFT.
   * Input length MUST be a power of two -- callers should pad/truncate
   * via nextPow2Window() below.
   * @param {number[]} real input samples (real-valued)
   * @returns {{re:number[], im:number[]}}
   */
  function fft(real) {
    const n = real.length;
    const re = Float64Array.from(real);
    const im = new Float64Array(n);

    // bit-reversal permutation
    for (let i = 1, j = 0; i < n; i++) {
      let bit = n >> 1;
      for (; j & bit; bit >>= 1) j ^= bit;
      j ^= bit;
      if (i < j) {
        [re[i], re[j]] = [re[j], re[i]];
        [im[i], im[j]] = [im[j], im[i]];
      }
    }

    for (let len = 2; len <= n; len <<= 1) {
      const ang = (-2 * Math.PI) / len;
      const wRe = Math.cos(ang), wIm = Math.sin(ang);
      for (let i = 0; i < n; i += len) {
        let curRe = 1, curIm = 0;
        for (let k = 0; k < len / 2; k++) {
          const uRe = re[i + k], uIm = im[i + k];
          const vRe = re[i + k + len / 2] * curRe - im[i + k + len / 2] * curIm;
          const vIm = re[i + k + len / 2] * curIm + im[i + k + len / 2] * curRe;
          re[i + k] = uRe + vRe;
          im[i + k] = uIm + vIm;
          re[i + k + len / 2] = uRe - vRe;
          im[i + k + len / 2] = uIm - vIm;
          const nextRe = curRe * wRe - curIm * wIm;
          const nextIm = curRe * wIm + curIm * wRe;
          curRe = nextRe; curIm = nextIm;
        }
      }
    }
    return { re: Array.from(re), im: Array.from(im) };
  }

  /** Largest power of two <= samples.length, capped at maxLen. */
  function nextPow2Window(samples, maxLen = 256) {
    let n = 1;
    while (n * 2 <= Math.min(samples.length, maxLen)) n *= 2;
    return samples.slice(samples.length - n);
  }

  /**
   * Full FFT magnitude spectrum with a Hann window applied (reduces
   * spectral leakage -- worth mentioning in the viva).
   * @returns {{freqs:number[], mags:number[]}} one-sided spectrum
   */
  function magnitudeSpectrum(samples, fs) {
    const windowed = nextPow2Window(samples);
    const n = windowed.length;
    if (n < 2) return { freqs: [], mags: [] };

    const hann = windowed.map((v, i) => v * (0.5 - 0.5 * Math.cos((2 * Math.PI * i) / (n - 1))));
    const { re, im } = fft(hann);

    const half = n / 2;
    const freqs = new Array(half);
    const mags = new Array(half);
    for (let k = 0; k < half; k++) {
      freqs[k] = (k * fs) / n;
      mags[k] = (2 / n) * Math.sqrt(re[k] * re[k] + im[k] * im[k]);
    }
    return { freqs, mags };
  }

  function rms(samples) {
    if (samples.length === 0) return 0;
    const sumSq = samples.reduce((s, v) => s + v * v, 0);
    return Math.sqrt(sumSq / samples.length);
  }

  function peak(samples) {
    if (samples.length === 0) return { max: 0, maxAbs: 0 };
    let max = -Infinity, maxAbs = 0;
    for (const v of samples) {
      if (v > max) max = v;
      if (Math.abs(v) > maxAbs) maxAbs = Math.abs(v);
    }
    return { max, maxAbs };
  }

  function dominantFrequency(freqs, mags) {
    if (freqs.length === 0) return { freq: 0, mag: 0 };
    let bestIdx = 0;
    for (let i = 1; i < mags.length; i++) {
      if (mags[i] > mags[bestIdx]) bestIdx = i;
    }
    return { freq: freqs[bestIdx], mag: mags[bestIdx] };
  }

  /** Sum of squared magnitude within [lowHz, highHz] -- a simple band-power proxy. */
  function bandPower(freqs, mags, lowHz, highHz) {
    let power = 0;
    for (let i = 0; i < freqs.length; i++) {
      if (freqs[i] >= lowHz && freqs[i] <= highHz) power += mags[i] * mags[i];
    }
    return power;
  }

  function signalEnergy(samples) {
    return samples.reduce((s, v) => s + v * v, 0);
  }

  /**
   * Runs the full pipeline on one window of raw samples and returns a
   * flat feature object. Used identically for baseline capture and for
   * live comparison.
   */
  function extractFeatures(rawSamples, filterSettings) {
    const { lowCutoff, highCutoff, fs } = filterSettings;
    const filtered = bandpassFilter(rawSamples, lowCutoff, highCutoff, fs);
    const { freqs, mags } = magnitudeSpectrum(filtered, fs);
    const dom = dominantFrequency(freqs, mags);
    const pk = peak(filtered);

    return {
      filtered,
      freqs,
      mags,
      rms: rms(filtered),
      peak: pk.max,
      peakAbs: pk.maxAbs,
      dominantFreq: dom.freq,
      dominantMag: dom.mag,
      bandPower: bandPower(freqs, mags, lowCutoff, highCutoff),
      energy: signalEnergy(filtered),
    };
  }

  /**
   * Compares live features against a stored baseline and returns a
   * prototype NORMAL / LEAK decision plus a per-parameter comparison
   * table. Thresholds are intentionally simple, named constants so
   * they can be replaced with experimentally derived values later
   * (see README.md, section "Where to change detection thresholds").
   */
  const DETECTION_THRESHOLDS = {
    rmsChangePct: 40,       // % increase in RMS vs baseline to flag
    bandPowerChangePct: 60, // % increase in band power vs baseline to flag
    freqShiftHz: 8,         // Hz shift in dominant frequency to flag
  };

  function pctChange(current, base) {
    if (!base || base === 0) return 0;
    return ((current - base) / Math.abs(base)) * 100;
  }

  function compareToBaseline(current, baseline) {
    if (!baseline) {
      return { status: 'UNKNOWN', reasons: ['No baseline set yet.'], table: null };
    }

    const rmsChange = pctChange(current.rms, baseline.rms);
    const peakChange = pctChange(current.peak, baseline.peak);
    const bpChange = pctChange(current.bandPower, baseline.bandPower);
    const freqShift = Math.abs(current.dominantFreq - baseline.dominantFreq);

    const reasons = [];
    if (rmsChange > DETECTION_THRESHOLDS.rmsChangePct) reasons.push(`RMS up ${rmsChange.toFixed(0)}%`);
    if (bpChange > DETECTION_THRESHOLDS.bandPowerChangePct) reasons.push(`Band power up ${bpChange.toFixed(0)}%`);
    if (freqShift > DETECTION_THRESHOLDS.freqShiftHz) reasons.push(`Dominant frequency shifted ${freqShift.toFixed(1)} Hz`);

    const status = reasons.length > 0 ? 'LEAK' : 'NORMAL';

    return {
      status,
      reasons,
      table: {
        rms: { base: baseline.rms, current: current.rms, changePct: rmsChange },
        peak: { base: baseline.peak, current: current.peak, changePct: peakChange },
        dominantFreq: { base: baseline.dominantFreq, current: current.dominantFreq, changePct: freqShift },
        bandPower: { base: baseline.bandPower, current: current.bandPower, changePct: bpChange },
      },
    };
  }

  return {
    bandpassFilter,
    fft,
    magnitudeSpectrum,
    rms,
    peak,
    dominantFrequency,
    bandPower,
    signalEnergy,
    extractFeatures,
    compareToBaseline,
    DETECTION_THRESHOLDS,
  };
})();
