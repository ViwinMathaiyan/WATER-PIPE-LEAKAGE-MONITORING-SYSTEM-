/*
 * simulation.js
 * -----------------------------------------------------------------------
 * Simulated data source. Feeds the SAME onSample(value) callback that
 * serial.js uses, so app.js runs one identical processing pipeline
 * regardless of where samples come from.
 *
 * Values are generated in ADC-count-like units centred around 512
 * (matching a typical "512,515,519..." ESP32 serial stream), NOT
 * claimed to be calibrated volts.
 * -----------------------------------------------------------------------
 */

const Simulation = (() => {
  let timer = null;
  let t = 0;
  let onSampleCallback = null;

  let settings = {
    mode: 'normal',        // 'normal' | 'leak'
    leakIntensity: 'medium', // 'low' | 'medium' | 'high'
    noiseLevel: 20,          // 0-100
    vibAmplitude: 40,        // 0-100
    simFrequency: 25,        // Hz, primary periodic component
    fs: 500,                 // samples/sec
  };

  const BASELINE_ADC = 512;

  const LEAK_GAIN = { low: 1.4, medium: 2.0, high: 3.0 };

  function updateSettings(partial) {
    settings = { ...settings, ...partial };
    if (timer) restart();
  }

  function gaussianNoise() {
    // Box-Muller transform for more realistic (non-uniform) sensor noise
    const u1 = Math.random(), u2 = Math.random();
    return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
  }

  function nextSample() {
    const dt = 1 / settings.fs;
    t += dt;

    const noiseScale = (settings.noiseLevel / 100) * 8;
    const ampScale = (settings.vibAmplitude / 100) * 60;
    const f1 = settings.simFrequency;

    // baseline flow noise -- always present, low-level, broadband-ish
    let value = BASELINE_ADC + gaussianNoise() * (noiseScale * 0.6);

    // primary periodic component (pump/flow related)
    value += ampScale * Math.sin(2 * Math.PI * f1 * t);
    // a secondary weaker harmonic, present even in normal flow
    value += ampScale * 0.25 * Math.sin(2 * Math.PI * (f1 * 2.3) * t + 0.7);

    if (settings.mode === 'leak') {
      const gain = LEAK_GAIN[settings.leakIntensity] || 2.0;
      // leak adds extra higher-frequency vibration content + more noise,
      // NOT just a bigger version of the same tone -- this is what makes
      // FFT/band-power comparison meaningful rather than arbitrary.
      const fLeak1 = f1 * 1.8 + 5;
      const fLeak2 = f1 * 3.1 + 11;
      value += ampScale * (gain - 1) * Math.sin(2 * Math.PI * fLeak1 * t + 0.3);
      value += ampScale * (gain - 1) * 0.6 * Math.sin(2 * Math.PI * fLeak2 * t + 1.1);
      value += gaussianNoise() * (noiseScale * 0.5 * gain);
    }

    return value;
  }

  function start(onSample) {
    onSampleCallback = onSample;
    restart();
  }

  function restart() {
    if (timer) clearInterval(timer);
    const intervalMs = Math.max(1, 1000 / settings.fs);
    // batch samples per tick when fs is high, since setInterval can't
    // reliably fire faster than ~1ms in a browser
    const samplesPerTick = intervalMs < 1 ? Math.round(settings.fs / 1000) : 1;
    timer = setInterval(() => {
      for (let i = 0; i < Math.max(1, samplesPerTick); i++) {
        if (onSampleCallback) onSampleCallback(nextSample());
      }
    }, Math.max(1, intervalMs));
  }

  function stop() {
    if (timer) clearInterval(timer);
    timer = null;
    onSampleCallback = null;
  }

  function isRunning() {
    return timer !== null;
  }

  return { start, stop, isRunning, updateSettings, get settings() { return settings; } };
})();
