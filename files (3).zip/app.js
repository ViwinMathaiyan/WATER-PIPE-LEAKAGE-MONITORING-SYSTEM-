/*
 * app.js
 * -----------------------------------------------------------------------
 * Orchestrates the single shared pipeline:
 *
 *   Data source (simulation.js OR serial.js)
 *        -> addSample(value)
 *        -> rolling sample buffer
 *        -> [every PROCESS_INTERVAL_MS] SignalProcessing.extractFeatures()
 *        -> charts + stat cards
 *        -> SignalProcessing.compareToBaseline()
 *        -> status banner
 *
 * Both data sources call the exact same addSample() function, so there
 * is only one processing path in the whole app (per the "no separate
 * logic for simulation vs ESP32" requirement).
 * -----------------------------------------------------------------------
 */

// ---------------------------------------------------------------------
// State
// ---------------------------------------------------------------------
const RAW_BUFFER_MAX = 1024;   // samples kept for the raw-signal chart
const FFT_WINDOW_MAX = 256;    // samples used per FFT / feature window
const PROCESS_INTERVAL_MS = 200; // how often we recompute features/charts

let rawBuffer = [];       // circular-ish array of {t, v}
let sampleIndex = 0;
let startTime = performance.now();

let baseline = null;      // stored feature snapshot
let latestFeatures = null;

let recording = false;
let recordedRows = []; // {timestamp, sample_index, raw_value, filtered_value}

let dataSourceMode = 'simulation'; // 'simulation' | 'esp32'

function getFilterSettings() {
  return {
    lowCutoff: parseFloat(document.getElementById('lowCutoff').value) || 1,
    highCutoff: parseFloat(document.getElementById('highCutoff').value) || 100,
    fs: parseFloat(document.getElementById('samplingFreq').value) || 500,
  };
}

// ---------------------------------------------------------------------
// Shared sample intake -- called by BOTH simulation.js and serial.js
// ---------------------------------------------------------------------
function addSample(value) {
  const now = (performance.now() - startTime) / 1000;
  rawBuffer.push({ t: now, v: value, idx: sampleIndex++ });
  if (rawBuffer.length > RAW_BUFFER_MAX) rawBuffer.shift();

  if (recording) {
    // filtered value is attached later once processed; placeholder here
    recordedRows.push({ timestamp: now.toFixed(4), sample_index: sampleIndex - 1, raw_value: value, filtered_value: null });
  }

  document.getElementById('sampleCountReadout').textContent = sampleIndex.toString();
}

// ---------------------------------------------------------------------
// Charts
// ---------------------------------------------------------------------
let rawChart, filteredChart, fftChart;

function initCharts() {
  const baseOptions = (xLabel, yLabel) => ({
    responsive: true,
    animation: false,
    maintainAspectRatio: false,
    scales: {
      x: { title: { display: true, text: xLabel, color: '#7C8699' }, ticks: { color: '#7C8699', maxTicksLimit: 8 }, grid: { color: '#1B2334' } },
      y: { title: { display: true, text: yLabel, color: '#7C8699' }, ticks: { color: '#7C8699' }, grid: { color: '#1B2334' } },
    },
    plugins: { legend: { display: false } },
    elements: { point: { radius: 0 }, line: { borderWidth: 1.5 } },
  });

  rawChart = new Chart(document.getElementById('rawChart'), {
    type: 'line',
    data: { labels: [], datasets: [{ data: [], borderColor: '#4FD1C5' }] },
    options: baseOptions('Time (s)', 'ADC counts'),
  });

  filteredChart = new Chart(document.getElementById('filteredChart'), {
    type: 'line',
    data: { labels: [], datasets: [{ data: [], borderColor: '#3ECF8E' }] },
    options: baseOptions('Time (s)', 'Amplitude'),
  });

  fftChart = new Chart(document.getElementById('fftChart'), {
    type: 'line',
    data: { labels: [], datasets: [{ data: [], borderColor: '#F5A623' }] },
    options: baseOptions('Frequency (Hz)', 'Magnitude'),
  });
}

function fmt(n, digits = 2) {
  if (n === undefined || n === null || Number.isNaN(n)) return '\u2014';
  return n.toFixed(digits);
}

// ---------------------------------------------------------------------
// Main processing tick
// ---------------------------------------------------------------------
function processTick() {
  if (rawBuffer.length < 8) return;

  const settings = getFilterSettings();
  const rawSlice = rawBuffer.slice(-FFT_WINDOW_MAX);
  const rawValues = rawSlice.map(p => p.v);

  const features = SignalProcessing.extractFeatures(rawValues, settings);
  latestFeatures = features;

  // --- raw chart ---
  rawChart.data.labels = rawBuffer.slice(-300).map(p => p.t.toFixed(2));
  rawChart.data.datasets[0].data = rawBuffer.slice(-300).map(p => p.v);
  rawChart.update('none');

  // --- filtered chart ---
  const filteredSlice = features.filtered.slice(-300);
  filteredChart.data.labels = rawSlice.slice(-300).map(p => p.t.toFixed(2));
  filteredChart.data.datasets[0].data = filteredSlice;
  filteredChart.update('none');

  // --- fft chart ---
  fftChart.data.labels = features.freqs.map(f => f.toFixed(0));
  fftChart.data.datasets[0].data = features.mags;
  fftChart.update('none');

  // --- stat cards ---
  document.getElementById('rmsValue').textContent = fmt(features.rms);
  document.getElementById('peakValue').textContent = fmt(features.peakAbs);
  document.getElementById('domFreqValue').textContent = fmt(features.dominantFreq, 1) + ' Hz';
  document.getElementById('bandPowerValue').textContent = fmt(features.bandPower, 0);
  document.getElementById('energyValue').textContent = fmt(features.energy, 0);
  document.getElementById('domFreqInline').textContent = fmt(features.dominantFreq, 1) + ' Hz';
  document.getElementById('domMagInline').textContent = fmt(features.dominantMag, 2);

  // --- baseline comparison / detection ---
  const cmp = SignalProcessing.compareToBaseline(features, baseline);
  updateStatus(cmp);

  // --- recording: backfill filtered value on most recent recorded row ---
  if (recording && recordedRows.length > 0 && filteredSlice.length > 0) {
    recordedRows[recordedRows.length - 1].filtered_value = filteredSlice[filteredSlice.length - 1];
  }
}

function updateStatus(cmp) {
  const statusEl = document.getElementById('statusValue');
  const captionEl = document.getElementById('statusPanel');

  if (cmp.status === 'UNKNOWN') {
    statusEl.textContent = 'AWAITING BASELINE';
    statusEl.className = 'status-value status-unknown';
  } else if (cmp.status === 'NORMAL') {
    statusEl.textContent = 'NORMAL PIPELINE';
    statusEl.className = 'status-value status-normal';
  } else {
    statusEl.textContent = 'LEAK DETECTED';
    statusEl.className = 'status-value status-leak';
  }

  if (cmp.table) {
    document.getElementById('cmpRmsBase').textContent = fmt(cmp.table.rms.base);
    document.getElementById('cmpRmsCur').textContent = fmt(cmp.table.rms.current);
    document.getElementById('cmpRmsChange').textContent = fmt(cmp.table.rms.changePct, 1) + '%';

    document.getElementById('cmpPeakBase').textContent = fmt(cmp.table.peak.base);
    document.getElementById('cmpPeakCur').textContent = fmt(cmp.table.peak.current);
    document.getElementById('cmpPeakChange').textContent = fmt(cmp.table.peak.changePct, 1) + '%';

    document.getElementById('cmpFreqBase').textContent = fmt(cmp.table.dominantFreq.base, 1) + ' Hz';
    document.getElementById('cmpFreqCur').textContent = fmt(cmp.table.dominantFreq.current, 1) + ' Hz';
    document.getElementById('cmpFreqChange').textContent = fmt(cmp.table.dominantFreq.changePct, 1) + ' Hz shift';

    document.getElementById('cmpBpBase').textContent = fmt(cmp.table.bandPower.base, 0);
    document.getElementById('cmpBpCur').textContent = fmt(cmp.table.bandPower.current, 0);
    document.getElementById('cmpBpChange').textContent = fmt(cmp.table.bandPower.changePct, 1) + '%';
  }
}

// ---------------------------------------------------------------------
// Baseline capture
// ---------------------------------------------------------------------
function setBaseline() {
  if (!latestFeatures) {
    alert('Not enough data yet. Start simulation or connect ESP32 first.');
    return;
  }
  baseline = {
    rms: latestFeatures.rms,
    peak: latestFeatures.peakAbs,
    dominantFreq: latestFeatures.dominantFreq,
    bandPower: latestFeatures.bandPower,
  };
  document.getElementById('baseRms').textContent = fmt(baseline.rms);
  document.getElementById('basePeak').textContent = fmt(baseline.peak);
  document.getElementById('baseFreq').textContent = fmt(baseline.dominantFreq, 1) + ' Hz';
  document.getElementById('baseBandPower').textContent = fmt(baseline.bandPower, 0);
  document.getElementById('baselineSetMini').textContent = 'Yes';
}

// ---------------------------------------------------------------------
// Recording / CSV export
// ---------------------------------------------------------------------
function startRecording() {
  recording = true;
  recordedRows = [];
  document.getElementById('startRecBtn').disabled = true;
  document.getElementById('stopRecBtn').disabled = false;
  document.getElementById('exportBtn').disabled = true;
  document.getElementById('recStatus').textContent = 'Recording...';
  document.getElementById('recordingMini').textContent = 'On';
}

function stopRecording() {
  recording = false;
  document.getElementById('startRecBtn').disabled = false;
  document.getElementById('stopRecBtn').disabled = true;
  document.getElementById('exportBtn').disabled = recordedRows.length === 0;
  document.getElementById('recStatus').textContent = `Stopped. ${recordedRows.length} samples captured.`;
  document.getElementById('recordingMini').textContent = 'Off';
}

function exportCSV() {
  const header = 'timestamp,sample_index,raw_value,filtered_value\n';
  const body = recordedRows.map(r => `${r.timestamp},${r.sample_index},${r.raw_value},${r.filtered_value ?? ''}`).join('\n');

  const summary = latestFeatures ? [
    '', '# Session summary',
    `# RMS,${fmt(latestFeatures.rms)}`,
    `# Peak,${fmt(latestFeatures.peakAbs)}`,
    `# Dominant Frequency,${fmt(latestFeatures.dominantFreq, 1)}`,
    `# Band Power,${fmt(latestFeatures.bandPower, 0)}`,
    `# Detection Result,${document.getElementById('statusValue').textContent}`,
  ].join('\n') : '';

  const csv = header + body + '\n' + summary;
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `pipeline-session-${Date.now()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

// ---------------------------------------------------------------------
// Data source wiring
// ---------------------------------------------------------------------
function setSourceBadge(mode) {
  const badge = document.getElementById('sourceBadge');
  const mini = document.getElementById('dataSourceMini');
  if (mode === 'esp32') {
    badge.textContent = 'ESP32 connected';
    badge.className = 'badge badge-live';
    mini.textContent = 'ESP32';
  } else {
    badge.textContent = 'Simulation mode';
    badge.className = 'badge badge-sim';
    mini.textContent = 'Simulation';
  }
  dataSourceMode = mode;
}

function wireSimulationControls() {
  document.getElementById('startSimBtn').addEventListener('click', () => {
    if (SerialSource.isConnected()) {
      alert('Disconnect ESP32 before starting simulation.');
      return;
    }
    Simulation.start(addSample);
    setSourceBadge('simulation');
    document.getElementById('startSimBtn').disabled = true;
    document.getElementById('stopSimBtn').disabled = false;
  });

  document.getElementById('stopSimBtn').addEventListener('click', () => {
    Simulation.stop();
    document.getElementById('startSimBtn').disabled = false;
    document.getElementById('stopSimBtn').disabled = true;
  });

  document.querySelectorAll('input[name="simMode"]').forEach(el => {
    el.addEventListener('change', (e) => Simulation.updateSettings({ mode: e.target.value }));
  });
  document.getElementById('leakIntensity').addEventListener('change', (e) => Simulation.updateSettings({ leakIntensity: e.target.value }));
  document.getElementById('noiseLevel').addEventListener('input', (e) => Simulation.updateSettings({ noiseLevel: parseFloat(e.target.value) }));
  document.getElementById('vibAmplitude').addEventListener('input', (e) => Simulation.updateSettings({ vibAmplitude: parseFloat(e.target.value) }));
  document.getElementById('simFrequency').addEventListener('input', (e) => Simulation.updateSettings({ simFrequency: parseFloat(e.target.value) }));
}

function wireSerialControls() {
  if (!SerialSource.isSupported()) {
    document.getElementById('connectBtn').disabled = true;
    document.getElementById('serialStatus').textContent = 'Web Serial API not supported in this browser. Use desktop Chrome or Edge (chrome://flags not required) served over HTTPS or localhost.';
  }

  document.getElementById('connectBtn').addEventListener('click', async () => {
    if (Simulation.isRunning()) {
      Simulation.stop();
      document.getElementById('startSimBtn').disabled = false;
      document.getElementById('stopSimBtn').disabled = true;
    }
    const ok = await SerialSource.connect(addSample, (status, msg) => {
      document.getElementById('serialStatus').textContent = msg;
      if (status === 'connected') {
        setSourceBadge('esp32');
        document.getElementById('connectBtn').disabled = true;
        document.getElementById('disconnectBtn').disabled = false;
      } else if (status === 'disconnected' || status === 'error') {
        setSourceBadge('simulation');
        document.getElementById('connectBtn').disabled = false;
        document.getElementById('disconnectBtn').disabled = true;
      }
    });
  });

  document.getElementById('disconnectBtn').addEventListener('click', async () => {
    await SerialSource.disconnect();
  });
}

function wireGeneralControls() {
  document.getElementById('clearBtn').addEventListener('click', () => {
    rawBuffer = [];
    sampleIndex = 0;
    startTime = performance.now();
  });

  document.getElementById('setBaselineBtn').addEventListener('click', setBaseline);

  document.getElementById('startRecBtn').addEventListener('click', startRecording);
  document.getElementById('stopRecBtn').addEventListener('click', stopRecording);
  document.getElementById('exportBtn').addEventListener('click', exportCSV);

  document.getElementById('samplingFreq').addEventListener('change', (e) => {
    document.getElementById('fsReadout').textContent = `${e.target.value} Hz`;
    Simulation.updateSettings({ fs: parseFloat(e.target.value) || 500 });
  });
}

// ---------------------------------------------------------------------
// Boot
// ---------------------------------------------------------------------
window.addEventListener('DOMContentLoaded', () => {
  initCharts();
  wireSimulationControls();
  wireSerialControls();
  wireGeneralControls();

  // auto-start in simulation mode so the dashboard is never empty
  Simulation.start(addSample);
  document.getElementById('startSimBtn').disabled = true;
  document.getElementById('stopSimBtn').disabled = false;

  setInterval(processTick, PROCESS_INTERVAL_MS);
});
